<?php

//SELECT * FROM `wp_effu8c_postmeta` WHERE post_id=31114;
?>